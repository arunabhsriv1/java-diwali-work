package com.cybage.services;



import java.sql.Date;
import java.util.List;

import com.cybage.pojos.Users;
import com.cybage.pojos.AllBatchInfo;
import com.cybage.pojos.Batch;
import com.cybage.pojos.Enrollment;
import com.cybage.pojos.Sports;

public interface ManagerServiceI {
	
	public int addSport(String sportName) throws Exception; 
	public int removeSport(String sportName) throws Exception; 
	public Batch getBatch(int batchId) throws Exception;
	public int addBatch(Batch batch) throws Exception;
	public Date getDate(String date);
	public int removeBatch(int batchId)throws Exception;
	public int updateBatch(Batch batch) throws Exception;
	
	public List<AllBatchInfo> getAllBatches()throws Exception;
	public Users getManager(String username)throws Exception;
	public List<AllBatchInfo> getAllEnrolledMembers() throws Exception;
	public int approveEnrollment(Enrollment enrlmnt)throws Exception;
	public int rejectEnrollment(Enrollment enrlmnt)throws Exception ;
	public int updateBatchSize(int enrollId,int batchSize)throws Exception;
	

}



